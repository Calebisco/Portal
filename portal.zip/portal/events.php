<?php
include 'includes/session.php';
include 'includes/functions.php';

global $mysqli;
global $session_userid;
global $active_event;
global $inactive_event;

AdminEventUpdate();

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" href="assets/css/files/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/files/calendar.min.css">
    <link rel="stylesheet" href="assets/css/files/dataTables.bootstrap.css">
    <link rel="stylesheet" href="assets/css/files/dataTables.fontAwesome.css">
    <link rel="stylesheet" href="assets/css/files/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/files/ekko-lightbox.min.css">
    <link rel="stylesheet" href="assets/css/files/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/files/select2.min.css">
    <link rel="stylesheet" href="assets/css/files/custom.css">

    <title>Student Portal | Events</title>

   

</head>

<body>
<div class="preloader"></div>

	<?php if (isset($_SESSION['signedIn']) && $_SESSION['signedIn'] == true) : ?>

    <?php if (isset($_SESSION['account_type']) && ($_SESSION['account_type'] == 'student' || $_SESSION['account_type'] == 'academic staff')) : ?>

	<?php include 'includes/menus/portal_menu.php'; ?>

	<div class="container">

	<ol class="breadcrumb breadcrumb-custom">
    <li><a href="../home/">Home</a></li>
	<li class="active">Events</li>
    </ol>

	<div class="row mb10">

	<div class="col-xs-6 col-sm-4 col-md-6 col-lg-6">
	<a id="task-button">
    <div class="tile task-tile">
	<i class="fa fa-ticket"></i>
	<p class="tile-text">Event view</p>
    </div>
    </a>
	</div>

	<div class="col-xs-6 col-sm-4 col-md-6 col-lg-6">
	<a id="calendar-button">
	<div class="tile calendar-tile">
    <i class="fa fa-calendar"></i>
	<p class="tile-text">Calendar view</p>
    </div>
    </a>
	</div>

	</div><!-- /row -->

	<div class="panel-group panel-custom event-view" id="accordion" role="tablist" aria-multiselectable="true">

	<div id="events-toggle" class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingOne">
  	<h4 class="panel-title">
	<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> Events</a>
  	</h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
  	<div class="panel-body">

	<!-- Event -->
	<section id="no-more-tables">
	<table class="table table-condensed table-custom event-table">

	<thead>
	<tr>
	<th>Name</th>
	<th>From</th>
	<th>To</th>
	<th>Price</th>
	<th>Tickets available</th>
	<th>Action</th>
	</tr>
	</thead>

	<tbody>
	<?php

    //Get active events
	$stmt1 = $mysqli->query("SELECT eventid, event_name, event_notes, event_url, DATE_FORMAT(event_from,'%d %b %y %H:%i') as event_from, DATE_FORMAT(event_to,'%d %b %y %H:%i') as event_to, event_amount, event_ticket_no FROM system_event WHERE event_status = 'active'");

	while($row = $stmt1->fetch_assoc()) {

	$eventid = $row["eventid"];
	$event_name = $row["event_name"];
	$event_notes = $row["event_notes"];
	$event_url = $row["event_url"];
	$event_from = $row["event_from"];
	$event_to = $row["event_to"];
	$event_amount = $row["event_amount"];
	$event_ticket_no = $row["event_ticket_no"];

	echo '<tr id="task-'.$eventid.'">

			<td data-title="Name"><a href="#view-'.$eventid.'" data-toggle="modal" data-dismiss="modal">'.$event_name.'</a></td>
			<td data-title="From">'.$event_from.'</td>
			<td data-title="To">'.$event_to.'</td>
			<td data-title="Price">'.$event_amount.'</td>
			<td data-title="Ticket available">'.($event_ticket_no === '0' ? "Sold Out" : "$event_ticket_no").'</td>
			<td data-title="Action">'.($event_ticket_no > 0 ? "<a class=\"btn btn-primary btn-md btn-load\" href=\"../events/book-event?id=$eventid\">Book</a>" : "<a class=\"btn btn-primary btn-md btn-disabled\" href=\"../events/book-event?id=$eventid\"<Book</a>").'</td>
			</tr>

			<div id="view-'.$eventid.'" class="modal fade modal-custom modal-info" tabindex="-1" role="dialog" aria-labelledby="modal-custom-label" aria-hidden="true">
    		<div class="modal-dialog">
    		<div class="modal-content">

			<div class="modal-header">
            <div class="close"><i class="fa fa-ticket"></i></div>
            <h4 class="modal-title" id="modal-custom-label">'.$event_name.'</h4>
			</div>

			<div class="modal-body">
			<p><b>Description:</b> '.(empty($event_notes) ? "-" : "$event_notes").'</p>
			<p><b>URL:</b> '.(empty($event_url) ? "-" : "$event_url").'</p>
			<p><b>From:</b> '.$event_from.'</p>
			<p><b>To:</b> '.$event_to.'</p>
			<p><b>Price (&pound;):</b> '.$event_amount.'</p>
			<p><b>Ticket available:</b> '.$event_ticket_no.'</p>
			</div>

			<div class="modal-footer">
            '.($event_ticket_no > 0 ? "<div class=\"view-action pull-left\"><a href=\"/events/book-event?id=$eventid\" class=\"btn btn-primary btn-md\">Book</a></div>" : "").'
			<div class="view-close pull-right">
			<a class="btn btn-danger btn-md" data-dismiss="modal">Close</a>
			</div>
			</div>

			</div><!-- /modal -->
			</div><!-- /modal-dialog -->
			</div><!-- /modal-content -->';
	}

	$stmt1->close();
	?>
	</tbody>

	</table>
	</section>

  	</div><!-- /panel-body -->
    </div><!-- /panel-collapse -->
	</div><!-- /panel-default -->

	<div id="bookedevents-toggle" class="panel panel-default">

    <div class="panel-heading" role="tab" id="headingTwo">
  	<h4 class="panel-title">
	<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo"> Booked events</a>
    </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
  	<div class="panel-body">

	<!-- Booked events -->
	<section id="no-more-tables">
	<table class="table table-condensed table-custom event-table">

	<thead>
	<tr>
	<th>Name</th>
	<th>Total paid</th>
	<th>Quantity</th>
	<th>Booked on</th>
	</tr>
	</thead>

	<tbody>
	<?php

    //Get booked events belonging to the currently signed in user
	$stmt2 = $mysqli->query("SELECT e.eventid, e.event_name, e.event_notes, e.event_url, e.event_from, e.event_to, e.event_amount, e.event_ticket_no, b.event_amount_paid, b.ticket_quantity, DATE_FORMAT(b.booked_on,'%d %b %y %H:%i') as booked_on FROM system_event_booked b LEFT JOIN system_event e ON b.eventid=e.eventid WHERE b.userid = '$session_userid'");

	while($row = $stmt2->fetch_assoc()) {

    $eventid = $row["eventid"];
    $event_name = $row["event_name"];
    $event_notes = $row["event_notes"];
    $event_url = $row["event_url"];
    $event_from = $row["event_from"];
    $event_to = $row["event_to"];
    $event_amount = $row["event_amount"];
    $event_ticket_no = $row["event_ticket_no"];

    $event_amount_paid = $row["event_amount_paid"];
    $ticket_quantity = $row["ticket_quantity"];
    $booked_on = $row["booked_on"];

	echo '<tr>

			<td data-title="Name">'.$event_name.'</td>
			<td data-title="Total paid">'.$event_amount_paid.'</td>
			<td data-title="Quantity">'.$ticket_quantity.'</td>
			<td data-title="Booked on">'.$booked_on.'</td>
			</tr>

			<div id="view-'.$eventid.'" class="modal fade modal-custom modal-info" tabindex="-1" role="dialog" aria-labelledby="modal-custom-label" aria-hidden="true">
    		<div class="modal-dialog">
    		<div class="modal-content">

			<div class="modal-header">
            <div class="close"><i class="fa fa-ticket"></i></div>
            <h4 class="modal-title" id="modal-custom-label">'.$event_name.'</h4>
			</div>

			<div class="modal-body">
			<p><b>Description:</b> '.(empty($event_notes) ? "-" : "$event_notes").'</p>
			<p><b>URL:</b> '.(empty($event_url) ? "-" : "$event_url").'</p>
			<p><b>From:</b> '.$event_from.'</p>
			<p><b>To:</b> '.$event_to.'</p>
			<p><b>Price (&pound;):</b> '.$event_amount.'</p>
			<p><b>Ticket available:</b> '.$event_ticket_no.'</p>
			</div>

			<div class="modal-footer">
			<div class="view-close pull-right">
			<a class="btn btn-danger btn-md" data-dismiss="modal">Close</a>
			</div>
			</div>

			</div><!-- /modal -->
			</div><!-- /modal-dialog -->
			</div><!-- /modal-content -->';
	}

	$stmt2->close();
	?>
	</tbody>

	</table>
	</section>

  	</div><!-- /panel-body -->
    </div><!-- /panel-collapse -->
	</div><!-- /panel-default -->

	</div><!-- /panel-group -->

	<div class="panel-group panel-custom calendar-view" id="accordion" role="tablist" aria-multiselectable="true">

	<div id="calendar-toggle" class="panel panel-default">
	<div class="panel-heading" role="tab" id="headingThree">
	<h4 class="panel-title">
	<a class="accordion-toggle" data-toggle="collapse" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree"> Calendar</a>
	</h4>
	</div>
	<div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree">
	<div class="panel-body">

	<div class="calendar-buttons text-right">
	<div id="calendar-buttons1" class="btn-group">
		<button class="btn btn-default" data-calendar-nav="prev"><< Prev</button>
		<button class="btn btn-default" data-calendar-nav="today">Today</button>
		<button class="btn btn-default" data-calendar-nav="next">Next >></button>
	</div>
	<div id="calendar-buttons2" class="btn-group">
		<button class="btn btn-default" data-calendar-view="year">Year</button>
		<button class="btn btn-default active" data-calendar-view="month">Month</button>
		<button class="btn btn-default" data-calendar-view="week">Week</button>
		<button class="btn btn-default" data-calendar-view="day">Day</button>
	</div>
	</div>

	<div class="page-header">
	<h3></h3>
	<hr>
	</div>

	<div id="calendar"></div>

	</div><!-- /panel-body -->
	</div><!-- /panel-collapse -->
	</div><!-- /panel-default -->

	</div><!-- /panel-group -->

    </div><!-- /container -->

	<?php include 'includes/footers/footer.php'; ?>
    <?php include 'assets/js-paths/common-js-paths.php'; ?>

    <script>
    $(document).ready(function () {
        //Event view/Calendar view toggle
        $("#calendar-toggle").hide();
        $(".task-tile").addClass("tile-selected");
        $(".task-tile p").addClass("tile-text-selected");
        $(".task-tile i").addClass("tile-text-selected");
    });

    //Initialize DataTables
    $('.table-custom').dataTable(settings);

	//Sets calendar options
	(function($) {

	"use strict";

	var options = {
		events_source: '../../includes/calendar/source/events_json.php',
		view: 'month',
		tmpl_path: '../assets/tmpls/',
		tmpl_cache: false,
		onAfterViewLoad: function(view) {
			$('.page-header h3').text(this.getTitle());
			$('.btn-group button').removeClass('active');
			$('button[data-calendar-view="' + view + '"]').addClass('active');
		},
		classes: {
			months: {
				general: 'label'
			}
		}
	};

	var calendar = $('#calendar').calendar(options);

	$('.btn-group button[data-calendar-nav]').each(function() {
		var $this = $(this);
		$this.click(function() {
			calendar.navigate($this.data('calendar-nav'));
		});
	});

	$('.btn-group button[data-calendar-view]').each(function() {
		var $this = $(this);
		$this.click(function() {
			calendar.view($this.data('calendar-view'));
		});
	});
	}(jQuery));

    //Responsiveness, full width button group on mobile device
    $(window).resize(function(){
        var width = $(window).width();
        if(width <= 480){
            $('.btn-group').addClass('btn-group-vertical full-width');
        } else {
            $('.btn-group').removeClass('btn-group-vertical full-width');
        }
    }).resize();

    //If task-button is clicked, do the following
    $("#task-button").click(function (e) {
    e.preventDefault();
        $(".calendar-view").hide();
		$("#calendar-toggle").hide();
        $(".event-view").show();
		$("#events-toggle").show();
		$("#bookedevents-toggle").show();
		$(".calendar-tile").removeClass("tile-selected");
		$(".calendar-tile p").removeClass("tile-text-selected");
		$(".calendar-tile i").removeClass("tile-text-selected");
		$(".task-tile").addClass("tile-selected");
		$(".task-tile p").addClass("tile-text-selected");
		$(".task-tile i").addClass("tile-text-selected");
	});

    //If calendar button is clicked, do the following
	$("#calendar-button").click(function (e) {
    e.preventDefault();
		$("#events-toggle").hide();
		$("#bookedevents-toggle").hide();
        $(".event-view").hide();
        $(".calendar-view").show();
		$("#calendar-toggle").show();
		$(".task-tile").removeClass("tile-selected");
		$(".task-tile p").removeClass("tile-text-selected");
		$(".task-tile i").removeClass("tile-text-selected");
		$(".calendar-tile").addClass("tile-selected");
		$(".calendar-tile p").addClass("tile-text-selected");
		$(".calendar-tile i").addClass("tile-text-selected");
	});
    </script>

    <?php endif; ?>

    <?php if (isset($_SESSION['account_type']) && $_SESSION['account_type'] == 'administrator') : ?>

    <?php include 'includes/menus/portal_menu.php'; ?>

    <div class="container">

	<ol class="breadcrumb breadcrumb-custom breadcrumb-admin">
    <li><a href="../home/">Home</a></li>
    <li class="active">Events</li>
    </ol>

    <a class="btn btn-success btn-lg btn-admin btn-load" href="../admin/create-event/">Create event</a>

    <div class="panel-group panel-custom book-view" id="accordion" role="tablist" aria-multiselectable="true">

	<div class="panel panel-default">

    <div class="panel-heading" role="tab" id="headingOne">
  	<h4 class="panel-title">
	<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> Events</a>
  	</h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
  	<div class="panel-body">

	<!-- Active events -->
	<section id="no-more-tables">
	<table class="table table-condensed table-custom table-active-event">

	<thead>
	<tr>
	<th>Name</th>
	<th>From</th>
	<th>To</th>
	<th>Price (&pound;)</th>
	<th>Tickets available</th>
	<th>Action</th>
	</tr>
	</thead>

	<tbody id="content-active-event">
	<?php
    echo $active_event;
	?>
	</tbody>

	</table>
	</section>

  	</div><!-- /panel-body -->
    </div><!-- /panel-collapse -->
	</div><!-- /panel-default -->

    <div class="panel panel-default">

    <div class="panel-heading" role="tab" id="headingThree">
  	<h4 class="panel-title">
	<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree"> Inactive events</a>
  	</h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
  	<div class="panel-body">

	<!-- Inactive events -->
	<section id="no-more-tables">
	<table class="table table-condensed table-custom table-inactive-event">

	<thead>
	<tr>
	<th>Event</th>
	<th>From</th>
	<th>To</th>
	<th>Price (&pound;)</th>
	<th>Tickets available</th>
    <th>Action</th>
	</tr>
	</thead>

	<tbody id="content-inactive-event">
	<?php
    echo $inactive_event;
	?>
	</tbody>

	</table>
	</section>

  	</div><!-- /panel-body -->
    </div><!-- /panel-collapse -->
	</div><!-- /panel-default -->

	</div><!-- /panel-group -->

    </div><!-- /container -->

	<?php include 'includes/footers/footer.php'; ?>

    <?php include 'assets/js-paths/common-js-paths.php'; ?>

	<script src="assets/js/files/jquery-2.1.3.min.js"></script>
    <script src="assets/js/files/moment.min.js"></script>
    <script src="assets/js/files/bootstrap-datetimepicker.min.js"></script>
    <script src="assets/js/files/bootstrap.min.js"></script>
    <script src="assets/js/files/jquery.dataTables.min.js"></script>
    <script src="assets/js/files/dataTables.bootstrap.js"></script>
    <script src="assets/js/files/select2.min.js"></script>
    <script src="assets/js/files/tileJs.min.js"></script>
    <script src="assets/js/files/html5shiv.min.js"></script>
    <script src="assets/js/files/respond.min.js"></script>
    <script src="assets/js/files/ie10-viewport-bug-workaround.min.js"></script>
    <script src="assets/js/files/ekko-lightbox.min.js"></script>
    <script src="assets/js/files/jstz.min.js"></script>
    <script src="assets/js/files/underscore-min.js"></script>
    <script src="assets/js/files/calendar.min.js"></script>
    <script src="assets/js/files/custom.js"></script>

    <script>
    //Initialize DataTables
    $('.table-active-event').dataTable(settings);
    $('.table-inactive-event').dataTable(settings);

    //Deactivate event process
    $("body").on("click", ".btn-deactivate-event", function(e) {
    e.preventDefault();

    //Get clicked ID
    var clickedID = this.id.split('-');
    var eventToDeactivate = clickedID[1];

    togglePreloader();

    //Initialize Ajax call
	jQuery.ajax({
	type: "POST",

    //URL to POST data to
	url: "https://student-portal.co.uk/includes/processes.php",
	dataType:"json",

    //Data posted
	data:'eventToDeactivate='+ eventToDeactivate,

    //If action completed, do the following
	success:function(html){

        togglePreloader();

        $(".table-active-event").dataTable().fnDestroy();
        $('#content-active-event').empty();
        $('#content-active-event').html(html.active_event);
        $(".table-active-event").dataTable(settings);

        $(".table-inactive-event").dataTable().fnDestroy();
        $('#content-inactive-event').empty();
        $('#content-inactive-event').html(html.inactive_event);
        $(".table-inactive-event").dataTable(settings);
	},

    //If action failed, do the following
	error:function (xhr, ajaxOptions, thrownError){
        togglePreloader();
		$("#error").show();
		$("#error").empty().append(thrownError);
	}
	});
    });

    //Reactivate event process
    $("body").on("click", ".btn-reactivate-event", function(e) {
    e.preventDefault();

    //Get clicked ID
    var clickedID = this.id.split('-');
    var eventToReactivate = clickedID[1];

    togglePreloader();

    //Initialize Ajax call
	jQuery.ajax({
	type: "POST",

    //URL to POST data to
	url: "https://student-portal.co.uk/includes/processes.php",
	dataType:"json",

    //Data posted
	data:'eventToReactivate='+ eventToReactivate,

    //If action completed, do the following
	success:function(html){

        togglePreloader();

        $(".table-inactive-event").dataTable().fnDestroy();
        $('#content-inactive-event').empty();
        $('#content-inactive-event').html(html.inactive_event);
        $(".table-inactive-event").dataTable(settings);

        $(".table-active-event").dataTable().fnDestroy();
        $('#content-active-event').empty();
        $('#content-active-event').html(html.active_event);
        $(".table-active-event").dataTable(settings);
	},

    //If action failed, do the following
	error:function (xhr, ajaxOptions, thrownError){
        togglePreloader();
		$("#error").show();
		$("#error").empty().append(thrownError);
	}
	});
    });

    //Delete event process
    $("body").on("click", ".btn-delete-event", function(e) {
    e.preventDefault();

    //Get clicked ID
    var clickedID = this.id.split('-');
    var eventToDelete = clickedID[1];

    //Initialize Ajax call
	jQuery.ajax({
	type: "POST",

    //URL to POST data to
	url: "https://student-portal.co.uk/includes/processes.php",
	dataType:"text",

    //Data posted
	data:'eventToDelete='+ eventToDelete,

    //If action completed, do the following
	success:function(html){

        $('.modal-custom').modal('hide');

        $('.modal-custom').on('hidden.bs.modal', function () {
            $(".table-active-event").dataTable().fnDestroy();
            $('#content-active-event').empty();
            $('#content-active-event').html(html.active_event);
            $(".table-active-event").dataTable(settings);

            $(".table-inactive-event").dataTable().fnDestroy();
            $('#content-inactive-event').empty();
            $('#content-inactive-event').html(html.inactive_event);
            $(".table-inactive-event").dataTable(settings);
        });
	},

    //If action failed, do the following
	error:function (xhr, ajaxOptions, thrownError){
		$("#error").show();
		$("#error").empty().append(thrownError);
	}
	});
    });
    </script>

    <?php endif; ?>

	<?php else : ?>

	<?php include 'includes/menus/menu.php'; ?>

    <div class="container">

	<form class="form-horizontal form-custom">

    <div class="form-logo text-center">
    <i class="fa fa-graduation-cap"></i>
    </div>

    <hr>
    <p class="feedback-danger text-center">Looks like you're not signed in yet. Please Sign in before accessing this area.</p>
    <hr>

    <div class="text-center">
	<a class="btn btn-primary btn-lg" href="/">Sign in</a>
    </div>

    </form>

	</div>

	<?php include 'includes/footers/footer.php'; ?>

	<?php endif; ?>

</body>
</html>
