<?php
include 'includes/session.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" href="assets/css/files/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/files/calendar.min.css">
    <link rel="stylesheet" href="assets/css/files/dataTables.bootstrap.css">
    <link rel="stylesheet" href="assets/css/files/dataTables.fontAwesome.css">
    <link rel="stylesheet" href="assets/css/files/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/files/ekko-lightbox.min.css">
    <link rel="stylesheet" href="assets/css/files/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/files/select2.min.css">
    <link rel="stylesheet" href="assets/css/files/custom.css">

    <title>Student Portal | About</title>

    <style>
    #about {
        background-color: #735326;
    }
    #about a {
        color: #FFFFFF;
    }
    #about a:focus, #about a:hover {
        color: #FFFFFF;
    }
    </style>

</head>

<body>

	<div class="preloader"></div>

	<?php if (isset($_SESSION['signedIn']) && $_SESSION['signedIn'] == true) : ?>

    <?php include 'includes/menus/portal_menu.php'; ?>

    <!-- About -->
    <div class="container text-center"><!-- container -->

    <ol class="breadcrumb breadcrumb-custom text-left">
        <li><a href="../../home/">Home</a></li>
        <li class="active">About</li>
    </ol>

    <div class="logo-custom">
    <i class="fa fa-comment-o" style="font-size: 150px;"></i>
    </div>
    <h1>Student Portal</h1>
	<h2>All your university needs, in one single place.</h2>
    </div><!-- ./container -->
    <!-- End of About -->

    <?php include 'includes/footers/footer.php'; ?>

    <?php include 'assets/js-paths/common-js-paths.php'; ?>

	<?php else : ?>

    <?php include 'includes/menus/menu.php'; ?>

    <!-- About -->
    <div class="container text-center"><!-- container -->
    <div class="logo-custom">
    <i class="fa fa-comment-o" style="font-size: 150px;"></i>
    </div>
    <h1>Student Portal</h1>
	<h2>All your university needs, in one single place.</h2>
    </div><!-- ./container -->
    <!-- End of About -->

    <?php include 'includes/footers/footer.php'; ?>

    <?php include 'assets/js-paths/common-js-paths.php'; ?>

	<?php endif; ?>
    <script src="assets/js/files/jquery-2.1.3.min.js"></script>
    <script src="assets/js/files/moment.min.js"></script>
    <script src="assets/js/files/bootstrap-datetimepicker.min.js"></script>
    <script src="assets/js/files/bootstrap.min.js"></script>
    <script src="assets/js/files/jquery.dataTables.min.js"></script>
    <script src="assets/js/files/dataTables.bootstrap.js"></script>
    <script src="assets/js/files/select2.min.js"></script>
    <script src="assets/js/files/tileJs.min.js"></script>
    <script src="assets/js/files/html5shiv.min.js"></script>
    <script src="assets/js/files/respond.min.js"></script>
    <script src="assets/js/files/ie10-viewport-bug-workaround.min.js"></script>
    <script src="assets/js/files/ekko-lightbox.min.js"></script>
    <script src="assets/js/files/jstz.min.js"></script>
    <script src="assets/js/files/underscore-min.js"></script>
    <script src="assets/js/files/calendar.min.js"></script>
    <script src="assets/js/files/custom.js"></script>
</body>
</html>
