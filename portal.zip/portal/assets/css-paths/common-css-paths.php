    <!-- favicon -->
    <link type="image/x-icon" href="https://student-portal.co.uk/assets/img/favicon/favicon.ico" rel="shortcut icon" property="shortcut icon">

    <!-- open-sans-font -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet" property="stylesheet">

    <!-- everything CSS -->
    <link href="https://student-portal.co.uk/assets/css/custom.min.css.php" rel="stylesheet" property="stylesheet">
