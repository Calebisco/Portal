    <!-- everything JS -->
    <script src="assets/js/custom.min.js.php"></script>