<?php
include 'includes/session.php';
include 'includes/functions.php';

//Call to SignOut function
SignOut();



