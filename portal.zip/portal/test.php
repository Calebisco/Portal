<?php
//Test only

include 'includes/session.php';
include 'includes/functions.php';

AdminResultUpdate($isUpdate = 1, $userid = 3);