<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" href="../../assets/css/files/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/files/calendar.min.css">
    <link rel="stylesheet" href="assets/css/files/dataTables.bootstrap.css">
    <link rel="stylesheet" href="assets/css/files/dataTables.fontAwesome.css">
    <link rel="stylesheet" href="assets/css/files/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/files/ekko-lightbox.min.css">
    <link rel="stylesheet" href="assets/css/files/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/files/select2.min.css">
    <link rel="stylesheet" href="assets/css/files/custom.css">
    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
    <div class="navbar-header">
    <!-- Toggle -->
    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
    <span class="sr-only">Toggle navigation</span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    </button>
    <!-- End of Toggle -->
    <a class="navbar-brand" href=""><i class="fa fa-graduation-cap"></i> Student Portal</a>
    </div>

    <div id="navbar" class="navbar-collapse collapse">
    <ul class="nav navbar-nav navbar-right">
        <li id="signin"><a href="/">Sign in</a></li>
        <li id="register"><a href="/register/">Register</a></li>
    </ul>
    </div><!--/.nav-collapse -->
    </div><!--/.container -->
    </nav>
    <!-- End of Navigation -->
