    <nav class="navbar navbar-default navbar-fixed-bottom">
    <div class="container">
    <div class="navbar-header">

    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar1" aria-expanded="false" aria-controls="navbar">
    <span class="sr-only">Toggle navigation</span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    </button>

    <a class="navbar-brand" href=""><i class="fa fa-copyright"></i> 2017 Student Portal</a>
    </div>
    <div id="navbar1" class="navbar-collapse collapse">
    <ul class="nav navbar-nav navbar-right">
    <li id="about"><a href="/about/">About</a></li>
    <li id="features"><a href="/features/">Features</a></li>
    <li id="user-manual"><a href="/user-manual/">User manual</a></li>
    <li id="contact"><a href="/contact/">Contact</a></li>
    </ul>
    </div><!--/.nav-collapse -->
    </div>
    </nav>
