<?php

//Database information to be used for connection (MySQLi)
define("HOST", "localhost");
define("USER", "root");
define("PASSWORD", ""); 
define("DATABASE", "portal");
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");

//Database information to be used for connection (PDO)

/*
$DB_HOST = "localhost";
$DB_NAME = "portal";
$DB_USER = "root";
$DB_PASS = "";
*/


