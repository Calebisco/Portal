
<?php
include 'includes/session.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" href="assets/css/files/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/files/calendar.min.css">
    <link rel="stylesheet" href="assets/css/files/dataTables.bootstrap.css">
    <link rel="stylesheet" href="assets/css/files/dataTables.fontAwesome.css">
    <link rel="stylesheet" href="assets/css/files/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/files/ekko-lightbox.min.css">
    <link rel="stylesheet" href="assets/css/files/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/files/select2.min.css">
    <link rel="stylesheet" href="assets/css/files/custom.css">


    <title>Student Portal</title>

    <style>
    #signin a {
        color: #FFFFFF;
        background-color: #992320;
    }
    #signin a:focus, #signin a:hover {
        color: #FFFFFF;
        background-color: #992320;
    }
    </style>

</head>

<body>
    
	<div class="preloader"></div>

	<?php if (isset($_SESSION['signedIn']) && $_SESSION['signedIn'] == true) : ?>

    

    <div class="container">

    <form class="form-horizontal form-custom">

    <div class="form-logo text-center">
    <i class="fa fa-graduation-cap"></i>
    </div>

    <hr>
    <p class="feedback-danger text-center">You are already logged in. You don't have to log in again.</p>
    <hr>

	<div class="pull-left">
    <a class="btn btn-success btn-lg" href="home.php">Home</a>
    </div>
	
    <div class="text-right">
    <a class="btn btn-danger btn-lg" href="sign-out.php">Sign Out</a>
    </div>

    </form>

    </div>

    <?php include 'includes/footers/footer.php'; ?>

    <?php include 'assets/js-paths/common-js-paths.php'; ?>

    <?php else : ?>

    <?php include 'assets/css-paths/common-css-paths.php'; ?>

    <?php include 'includes/menus/menu.php'; ?>

    <div class="container">

    <form class="form-horizontal form-custom" name="signin_form" id="signin_form">

    <div class="form-logo text-center">
	<i class="fa fa-graduation-cap"></i>
    </div>

    <hr>

    <p id="error" class="feedback-danger text-center"></p>

    <div class="form-group">
    <div class="col-xs-12 col-sm-12 full-width">
    <label for="email">Email address</label>
    <input class="form-control" type="email" name="email" id="email" placeholder="Enter an email address">
    </div>
    </div>

    <div class="form-group">
    <div class="col-xs-12 col-sm-12 full-width">
    <label for="password">Password</label>
    <input class="form-control" type="password" name="password" id="password" placeholder="Enter a password">
    </div>
    </div>

    <div class="text-right">
    <a class="forgot-password" href="forgotten-password.php">Forgotten your password?</a>
    </div>

    <hr>

    <div class="pull-left">
    <a class="btn btn-info btn-lg btn-load" href="register.php">Register</a>
    </div>

    <div class="text-right">
    <a id="sign-in-submit" class="btn btn-primary btn-lg btn-load" >Sign in</a>
	</div>

    </form>

    </div>

    <?php include 'includes/footers/footer.php'; ?>

    <?php include 'assets/js-paths/common-js-paths.php'; ?>

    
    <script src="assets/js/files/jquery-2.1.3.min.js"></script>
    <script src="assets/js/files/moment.min.js"></script>
    <script src="assets/js/files/bootstrap-datetimepicker.min.js"></script>
    <script src="assets/js/files/bootstrap.min.js"></script>
    <script src="assets/js/files/jquery.dataTables.min.js"></script>
    <script src="assets/js/files/dataTables.bootstrap.js"></script>
    <script src="assets/js/files/select2.min.js"></script>
    <script src="assets/js/files/tileJs.min.js"></script>
    <script src="assets/js/files/html5shiv.min.js"></script>
    <script src="assets/js/files/respond.min.js"></script>
    <script src="assets/js/files/ie10-viewport-bug-workaround.min.js"></script>
    <script src="assets/js/files/ekko-lightbox.min.js"></script>
    <script src="assets/js/files/jstz.min.js"></script>
    <script src="assets/js/files/underscore-min.js"></script>
    <script src="assets/js/files/calendar.min.js"></script>
    <script src="assets/js/files/custom.js"></script>

    <script>

    //Sign In process
    $("#sign-in-submit").click(function (e) {
    e.preventDefault();

    var hasError = false;

    //Checking if email is inputted
	var email = $('#email').val();
	if (email === '') {
        $("label[for='email']").empty().append("Please enter an email address.");
        $("label[for='email']").removeClass("feedback-success");
        $("label[for='email']").addClass("feedback-danger");
        $("#email").removeClass("input-success");
        $("#email").addClass("input-danger");
        $("#email").focus();
		hasError  = true;
        return false;
	} else {
        $("label[for='email']").empty().append("All good!");
        $("label[for='email']").removeClass("feedback-danger");
        $("label[for='email']").addClass("feedback-success");
        $("#email").removeClass("input-danger");
        $("#email").addClass("input-success");
	}

    //Checking if password is inputted
	var password = $("#password").val();
	if(password === '') {
        $("label[for='password']").empty().append("Please enter a password.");
        $("label[for='password']").removeClass("feedback-success");
        $("label[for='password']").addClass("feedback-danger");
        $("#password").removeClass("input-success");
        $("#password").addClass("input-danger");
        $("#password").focus();
		hasError  = true;
        return false;
    } else {
        $("label[for='password']").empty().append("All good!");
        $("label[for='password']").removeClass("feedback-danger");
        $("label[for='password']").addClass("feedback-success");
        $("#password").removeClass("input-danger");
        $("#password").addClass("input-success");
	}

    //If there are no errors, initialize the Ajax call
	if(hasError == false){

    //Initialize Ajax call
    jQuery.ajax({
	type: "POST",

    //URL to POST data to
	url: "includes/processes.php",

    //Data posted
    data:'email=' + email + '&password=' + password,

    //If action completed, do the following
    success:function(){
		window.location = 'home.php';
    },

    //If action failed, do the following
    error:function (xhr, ajaxOptions, thrownError){
        buttonReset();
        $("#success").hide();
		$("#error").show();
        $("#error").empty().append(thrownError);
    }
	});
    }

	return true;

	});
	</script>

	<?php endif; ?>

</body>
</html>
